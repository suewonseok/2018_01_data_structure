var searchData=
[
  ['template_20class_2e',['Template class.',['../index.html',1,'']]]
];
