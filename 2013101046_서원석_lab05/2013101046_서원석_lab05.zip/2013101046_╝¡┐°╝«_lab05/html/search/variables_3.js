var searchData=
[
  ['prev',['prev',['../struct_node_type.html#a6b3b367ea1d14bbf1efea63af65dfe27',1,'NodeType']]]
];
