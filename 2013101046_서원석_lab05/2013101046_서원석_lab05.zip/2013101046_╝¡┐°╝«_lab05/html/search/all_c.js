var searchData=
[
  ['userinterface',['userInterface',['../class_application.html#afaab30b5900388e6be28e16dea584bb2',1,'Application']]]
];
