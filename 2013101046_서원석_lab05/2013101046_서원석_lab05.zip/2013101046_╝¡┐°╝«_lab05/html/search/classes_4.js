var searchData=
[
  ['papertype',['PaperType',['../class_paper_type.html',1,'']]]
];
