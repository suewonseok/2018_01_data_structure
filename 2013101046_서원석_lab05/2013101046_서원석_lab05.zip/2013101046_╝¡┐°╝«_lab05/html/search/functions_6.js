var searchData=
[
  ['makeempty',['MakeEmpty',['../class_array_list.html#aeb5c3ca1b3d2352a866181c4cb8992ce',1,'ArrayList']]],
  ['manageconference',['manageConference',['../class_application.html#a77e2f702a888725e83a9aa8555fe6e9c',1,'Application']]],
  ['managepaper',['managePaper',['../class_application.html#abdea0e0ef63ecff3a1bbdbc3c6ee5134',1,'Application']]],
  ['managesession',['manageSession',['../class_application.html#a459ef4ba4cf97ef2b8e8ad84e59a7382',1,'Application']]]
];
