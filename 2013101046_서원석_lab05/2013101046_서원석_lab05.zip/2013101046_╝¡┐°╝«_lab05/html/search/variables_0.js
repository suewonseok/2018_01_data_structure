var searchData=
[
  ['data',['data',['../struct_node_type.html#a906930ecc125d29ebc8b42577374e494',1,'NodeType']]]
];
