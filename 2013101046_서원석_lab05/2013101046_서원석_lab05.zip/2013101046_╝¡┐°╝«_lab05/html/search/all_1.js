var searchData=
[
  ['comparebyname',['CompareByName',['../class_conference_type.html#a5f7c55136353af37272909ba29b0a632',1,'ConferenceType::CompareByName()'],['../class_paper_type.html#aec76826d6415302481127ad5f5a696ae',1,'PaperType::CompareByName()'],['../class_session_type.html#a6cf80d1526a81d45e06264054706e7a8',1,'SessionType::CompareByName()']]],
  ['conferencetype',['ConferenceType',['../class_conference_type.html',1,'ConferenceType'],['../class_conference_type.html#a17477aeda9dd54db8145efb7f7ab03cd',1,'ConferenceType::ConferenceType()']]]
];
