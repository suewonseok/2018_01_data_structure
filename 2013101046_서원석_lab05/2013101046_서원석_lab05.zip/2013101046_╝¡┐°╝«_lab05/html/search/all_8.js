var searchData=
[
  ['p_5fretrivebyname',['p_RetriveByName',['../class_application.html#ac1ffeba5b96b7b192c56a9c352a68604',1,'Application']]],
  ['papertype',['PaperType',['../class_paper_type.html',1,'PaperType'],['../class_paper_type.html#a7056cada331378a439974413e95982b4',1,'PaperType::PaperType()']]],
  ['prev',['prev',['../struct_node_type.html#a6b3b367ea1d14bbf1efea63af65dfe27',1,'NodeType']]]
];
